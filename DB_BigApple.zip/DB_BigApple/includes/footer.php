

	<div class="footer">
		<div class="footer_resize">
			
			<div class="clr"></div>
		</div>
	</div>
	
	<div align=center>
		
		<a href='https://github.com/jjs816'>www.bigapple.com</a>
		
	</div>
