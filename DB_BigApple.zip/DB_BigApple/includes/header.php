<html>
<head>
<title>MTA Data Analysis</title>

<!-- Javascript -->

<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/bootbox.min.js"></script>
<script src="assets/js/demo.js"></script>
<script src="assets/js/jquery.jcrop.js"></script>

<!-- mine -->

<script type="text/javascript" src="assets/js/script.js"></script>
<script type="text/javascript" src="assets/js/cufon-yui.js"></script>
<script type="text/javascript" src="assets/js/arial.js"></script>
<script type="text/javascript" src="assets/js/cuf_run.js"></script>

<!-- CSS -->
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="assets/css/style.css">

<!-- mine -->
<link href="assets/css/headstyle.css" rel="stylesheet" type="text/css" />
</head>


<body>

	<div class="main">
		<div class="main_resize">
			<div class="header">
				<div class="logo">
					<h1>
						<a href="home.php">
							<span>MTA</span>Data
							<span>Analysis</span>
						</a>
					</h1>
				</div>
				

				<!-- menu bar -->
				<div class="clr"></div>
				<div class="menu_nav">
					<ul>
						<li>
							<a href="home.php">
								Home
								<i class="fa fa-home fa-lg"></i>
							</a>
						</li>
						<li>
							<a href="">Something
							</a>
						</li>
						<li>
							<a href="">Something</a>
						</li>
					</ul>
					<div class="clr"></div>
				</div>

			</div>

		</div>
	</div>