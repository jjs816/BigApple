Move these files to htdocs and then run localhost.
